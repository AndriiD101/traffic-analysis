# Real-Time Vehicle Traffic Analysis

Detects vehicles from an RTSP camera stream, tracks them with persistent IDs,
classifies each vehicle's color, and reads license plates via OCR - tuned to
run in real time on edge/CPU hardware.

## 1. Installation

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
```

**CPU-only edge devices:** install the CPU build of PyTorch first to avoid
pulling a large CUDA package:

```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.txt
```

The first run will auto-download `yolov8n.pt` (~6 MB) and EasyOCR's
recognition/detection models (~100 MB) - make sure the machine has internet
access at least once, or pre-seed those files.

## 2. Usage

```bash
python main.py --source rtsp://user:password@192.168.1.10:554/Streaming/Channels/101
```

Useful flags:

| Flag            | Default     | Description                                                       |
|-----------------|-------------|---------------------------------------------------------------------|
| `--source`      | *(required)*| RTSP URL, video file path, or webcam index (`0`) for local testing. |
| `--model`       | `yolov8n.pt`| Ultralytics weights to use.                                          |
| `--conf`        | `0.4`       | Detection confidence threshold.                                     |
| `--imgsz`       | `640`       | Inference resolution fed to YOLO (lower = faster, less accurate).   |
| `--device`      | `cpu`       | `cpu`, `cuda:0`, etc.                                                |
| `--classes`     | `car`       | Comma list from `car,motorcycle,bus,truck`.                          |
| `--gpu-ocr`     | off         | Run EasyOCR on GPU.                                                  |
| `--no-display`  | off         | Headless mode (no `cv2.imshow` window).                              |

Quick local test with a webcam instead of RTSP:

```bash
python main.py --source 0
```

Press **`q`** in the video window to quit.

## 3. Architecture & Approach

**Detection & Tracking - YOLOv8n + ByteTrack.**
YOLOv8n is the smallest model in the YOLOv8 family, purpose-built for
edge/CPU inference while keeping reasonable accuracy on common object
classes (cars, trucks, buses, motorcycles are all in COCO). Rather than
running a separate tracker, we use `model.track(..., tracker="bytetrack.yaml")`,
Ultralytics' built-in integration of ByteTrack. ByteTrack is chosen because
it's motion/IoU-based (no re-identification network to run), so it adds
negligible overhead on top of detection while still assigning stable IDs
through brief occlusions or missed detections.

**Color detection - OpenCV, K-Means + HSV rules.**
For each vehicle crop we take a *center* sub-region (skipping background,
glass/reflections, and shadowed edges), downsample it to ~48x48 pixels, and
run a 3-cluster K-Means to find the dominant color. The dominant BGR pixel
is converted to HSV and classified into one of ten common vehicle colors
using simple threshold rules (achromatic colors - black/white/gray/silver -
are separated first by low saturation/value, then chromatic colors are
binned by hue). This avoids training or loading a separate color-classification
model; the whole operation costs a few milliseconds on CPU.

**License plate OCR - EasyOCR.**
Rather than adding a third model (a dedicated plate detector), we feed
EasyOCR the *lower half* of each vehicle's bounding box, where plates are
normally mounted. This trades a small amount of OCR robustness for one
fewer model to run per frame - a reasonable trade-off for a resource
constrained edge device. Results are cleaned (uppercased, non-alphanumeric
characters stripped) and filtered by length and OCR confidence before being
accepted.

**Frame filtering / caching - the core edge optimization.**
Running detection every frame is affordable with YOLOv8n, so tracking
continuity is preserved by evaluating YOLO+ByteTrack on (almost) every
frame. What's *not* affordable to run every frame, for every vehicle, is
OCR and repeated K-Means color sampling. Instead:

- **Per-track caching**: color and plate results are stored in a dictionary
  keyed by track ID (`track_cache[track_id]`), so each is computed only when
  needed instead of on every frame.
- **Color sampling then lock**: color is sampled for the first 5 frames a
  track is seen, then the majority-vote color is locked in - it doesn't
  change again for that ID, eliminating repeated K-Means calls.
- **OCR retry-then-lock**: OCR is retried every 15 frames until a
  high-confidence read (>=0.70) is obtained, after which it's locked and
  skipped entirely for that track. Crops below a minimum pixel area are
  skipped outright (too small to read reliably).
- **Global sparse mode**: if 30 consecutive frames produce zero detections
  (empty scene / no traffic), the pipeline switches to running full
  detection only every 5th frame until a vehicle reappears, saving GPU/CPU
  cycles when the road is empty.
- **Cache eviction**: cached data for a track ID is dropped if that ID
  hasn't been seen for 300 frames, keeping memory bounded on long-running
  streams.

**Resilience.**
RTSP connections are wrapped in `RTSPStream`, which retries with
exponential backoff (up to `--max-retries`) whenever a read fails or the
connection drops, so a temporary network blip doesn't crash the process.

## 4. Known limitations / next steps

- OCR is run on the raw vehicle crop rather than a dedicated plate
  detection stage, so plate read rate depends on camera angle/resolution;
  swapping in a small plate-detector model (e.g., a YOLO model fine-tuned
  on plates) would improve accuracy at some extra compute cost.
- Color classification is heuristic-based; a tiny trained classifier could
  improve accuracy in extreme lighting.
- No persistence layer is included (e.g., logging plates/colors to a
  database or CSV) - this can be added by writing `track_cache` entries out
  on track eviction.
