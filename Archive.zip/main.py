"""
Real-time vehicle traffic analysis over an RTSP stream.

Pipeline per frame:
  1. YOLOv8n detects vehicles; ByteTrack (built into Ultralytics) assigns
     and persists a track ID per vehicle across frames.
  2. For each tracked vehicle, color and license plate are computed only a
     limited number of times per track ID (cached + eventually locked),
     instead of every frame - this is the main edge-optimization lever.
  3. Boxes are drawn using the vehicle's detected color, annotated with the
     track ID and (if read) the plate text.

Usage:
    python main.py --source rtsp://user:pass@192.168.1.10:554/stream1
"""

import argparse
import time
from collections import defaultdict

import cv2
import numpy as np
from ultralytics import YOLO

from utils import get_dominant_color, extract_license_plate, init_ocr_reader

# COCO class IDs relevant to "vehicles". 2=car, 3=motorcycle, 5=bus, 7=truck.
VEHICLE_CLASSES = {2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}

# --- Tunable pipeline constants -------------------------------------------
COLOR_SAMPLE_COUNT = 5        # samples per track before locking in a color
OCR_RETRY_INTERVAL = 15       # frames between OCR attempts while unlocked
PLATE_LOCK_CONFIDENCE = 0.70  # confidence at which we stop re-running OCR
MIN_PLATE_CROP_AREA = 1500    # px^2; skip OCR on crops too small to read
TRACK_TTL_FRAMES = 300        # drop cached data for tracks unseen this long

EMPTY_FRAMES_BEFORE_SKIP = 30 # consecutive empty frames before we throttle
SKIP_INTERVAL_WHEN_EMPTY = 5  # only run detection every Nth frame when empty

DISPLAY_MAX_WIDTH = 800       # display window is capped to this width...
FONT_SCALE = 0.85             # ...while label text is scaled UP for readability
FONT_THICKNESS = 2
BOX_THICKNESS = 2
# ---------------------------------------------------------------------------


def parse_args():
    parser = argparse.ArgumentParser(description="Real-time vehicle traffic analysis over RTSP.")
    parser.add_argument("--source", required=True,
                         help="RTSP URL of the camera stream (e.g. rtsp://user:pass@ip:554/stream1). "
                              "A local video file path or webcam index also works for testing.")
    parser.add_argument("--model", default="yolov8n.pt",
                         help="Ultralytics YOLO weights to use. Default: yolov8n.pt (fast, edge-friendly).")
    parser.add_argument("--conf", type=float, default=0.4, help="Detection confidence threshold.")
    parser.add_argument("--imgsz", type=int, default=640, help="Inference image size fed to YOLO.")
    parser.add_argument("--device", default="cpu", help="Inference device: 'cpu', 'cuda:0', etc.")
    parser.add_argument("--classes", default="car",
                         help="Comma-separated vehicle classes to detect: car,motorcycle,bus,truck. "
                              "Default: car")
    parser.add_argument("--gpu-ocr", action="store_true", help="Run EasyOCR on GPU instead of CPU.")
    parser.add_argument("--no-display", action="store_true",
                         help="Run headless (no cv2.imshow window) - useful on servers.")
    parser.add_argument("--max-retries", type=int, default=10,
                         help="Max consecutive reconnect attempts before giving up on the stream.")
    parser.add_argument("--display-width", type=int, default=DISPLAY_MAX_WIDTH,
                         help="Max width (px) of the display window. Detection still runs at "
                              "full resolution; annotations are scaled so text stays readable "
                              "even in a smaller window. Default: 800.")
    return parser.parse_args()


class RTSPStream:
    """Thin wrapper around cv2.VideoCapture that transparently reconnects
    on read failures / dropped connections, with exponential backoff."""

    def __init__(self, source, max_retries=10, retry_delay=2.0, retry_delay_cap=30.0):
        self.source = source
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.retry_delay_cap = retry_delay_cap
        self.cap = None
        if not self._open():
            raise RuntimeError(f"Could not open video source on startup: {source}")

    def _open(self):
        if self.cap is not None:
            self.cap.release()
        self.cap = cv2.VideoCapture(self.source)
        try:
            # Keep internal buffer small so we don't fall behind on RTSP.
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass
        return self.cap.isOpened()

    def read(self):
        if self.cap is None or not self.cap.isOpened():
            if not self._reconnect():
                return False, None
        ok, frame = self.cap.read()
        if not ok:
            if not self._reconnect():
                return False, None
            ok, frame = self.cap.read()
        return ok, frame

    def _reconnect(self):
        delay = self.retry_delay
        for attempt in range(1, self.max_retries + 1):
            print(f"[stream] connection lost. Reconnect attempt {attempt}/{self.max_retries} "
                  f"to {self.source} ...")
            if self._open():
                print("[stream] reconnected successfully.")
                return True
            time.sleep(delay)
            delay = min(delay * 1.5, self.retry_delay_cap)
        print("[stream] failed to reconnect after max retries. Giving up.")
        return False

    def release(self):
        if self.cap is not None:
            self.cap.release()


def new_cache_entry(frame_idx):
    return {
        "color_samples": [],          # list of (name, bgr) until locked
        "color_name": None,
        "box_color": (0, 255, 0),     # default green until classified
        "plate_text": None,
        "plate_conf": 0.0,
        "plate_locked": False,
        "frames_since_ocr": OCR_RETRY_INTERVAL,  # force an attempt on first sight
        "last_seen": frame_idx,
    }


def draw_annotation(frame, box, track_id, cache, class_name,
                     font_scale=FONT_SCALE, font_thickness=FONT_THICKNESS,
                     box_thickness=BOX_THICKNESS):
    x1, y1, x2, y2 = box
    color = cache["box_color"]

    cv2.rectangle(frame, (x1, y1), (x2, y2), color, box_thickness)

    label_parts = [f"ID {track_id}", class_name]
    if cache["color_name"]:
        label_parts.append(cache["color_name"])
    if cache["plate_text"]:
        label_parts.append(cache["plate_text"])
    label = " | ".join(label_parts)

    (text_w, text_h), baseline = cv2.getTextSize(
        label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, font_thickness)
    label_y1 = max(y1 - text_h - baseline - 8, 0)
    cv2.rectangle(frame, (x1, label_y1), (x1 + text_w + 8, y1), color, -1)

    # Choose readable text color against the box color's background.
    brightness = 0.299 * color[2] + 0.587 * color[1] + 0.114 * color[0]
    text_color = (0, 0, 0) if brightness > 140 else (255, 255, 255)
    cv2.putText(frame, label, (x1 + 4, y1 - baseline - 4),
                cv2.FONT_HERSHEY_SIMPLEX, font_scale, text_color, font_thickness, cv2.LINE_AA)


def main():
    args = parse_args()

    requested_names = {c.strip().lower() for c in args.classes.split(",") if c.strip()}
    class_ids = [cid for cid, name in VEHICLE_CLASSES.items() if name in requested_names]
    if not class_ids:
        print(f"[config] No valid classes matched '{args.classes}', defaulting to 'car'.")
        class_ids = [2]

    print(f"[init] Loading YOLO model '{args.model}' on device '{args.device}' ...")
    model = YOLO(args.model)

    print("[init] Loading EasyOCR reader (this can take a moment on first run) ...")
    ocr_reader = init_ocr_reader(languages=("en",), gpu=args.gpu_ocr)

    print(f"[init] Opening stream: {args.source}")
    # Allow plain integers for local webcam testing (e.g. --source 0).
    source = int(args.source) if args.source.isdigit() else args.source
    stream = RTSPStream(source, max_retries=args.max_retries)

    track_cache = defaultdict(lambda: None)
    frame_idx = 0
    consecutive_empty_frames = 0

    fps_smoothed = 0.0
    prev_time = time.time()
    window_ready = False

    print("[run] Starting main loop. Press 'q' in the video window to quit.")
    try:
        while True:
            ok, frame = stream.read()
            if not ok:
                print("[run] Stream ended or unrecoverable. Exiting.")
                break

            frame_idx += 1

            # --- Frame filtering: throttle full detection during long empty spells ---
            run_detection = True
            if consecutive_empty_frames >= EMPTY_FRAMES_BEFORE_SKIP:
                run_detection = (frame_idx % SKIP_INTERVAL_WHEN_EMPTY == 0)

            detections = []
            if run_detection:
                results = model.track(
                    frame,
                    persist=True,
                    classes=class_ids,
                    conf=args.conf,
                    imgsz=args.imgsz,
                    device=args.device,
                    tracker="bytetrack.yaml",
                    verbose=False,
                )
                boxes = results[0].boxes
                if boxes is None or boxes.id is None or len(boxes) == 0:
                    consecutive_empty_frames += 1
                else:
                    consecutive_empty_frames = 0
                    xyxy = boxes.xyxy.cpu().numpy().astype(int)
                    ids = boxes.id.cpu().numpy().astype(int)
                    clss = boxes.cls.cpu().numpy().astype(int)
                    for box, tid, cid in zip(xyxy, ids, clss):
                        detections.append((box, int(tid), int(cid)))

            h_frame, w_frame = frame.shape[:2]
            seen_ids_this_frame = set()

            # Display window is capped to DISPLAY_MAX_WIDTH, but we draw the
            # annotations at an *inflated* font/line size on the full-res
            # frame first, then downscale everything together. That way the
            # final on-screen text ends up sharp and comfortably readable
            # even though the window itself is smaller.
            display_scale = min(1.0, args.display_width / w_frame) if w_frame > 0 else 1.0
            draw_font_scale = FONT_SCALE / display_scale if display_scale > 0 else FONT_SCALE
            draw_font_thickness = max(1, round(FONT_THICKNESS / display_scale))
            draw_box_thickness = max(1, round(BOX_THICKNESS / display_scale))

            for box, track_id, cls_id in detections:
                x1, y1, x2, y2 = box
                x1, y1 = max(x1, 0), max(y1, 0)
                x2, y2 = min(x2, w_frame - 1), min(y2, h_frame - 1)
                if x2 <= x1 or y2 <= y1:
                    continue

                crop = frame[y1:y2, x1:x2]
                if crop.size == 0:
                    continue

                seen_ids_this_frame.add(track_id)
                if track_cache[track_id] is None:
                    track_cache[track_id] = new_cache_entry(frame_idx)
                cache = track_cache[track_id]
                cache["last_seen"] = frame_idx

                # --- Color detection: sample a few times, then lock in the mode ---
                if len(cache["color_samples"]) < COLOR_SAMPLE_COUNT:
                    name, bgr = get_dominant_color(crop)
                    cache["color_samples"].append((name, bgr))
                    if len(cache["color_samples"]) == COLOR_SAMPLE_COUNT:
                        names = [s[0] for s in cache["color_samples"]]
                        mode_name = max(set(names), key=names.count)
                        mode_bgr = next(b for n, b in cache["color_samples"] if n == mode_name)
                        cache["color_name"], cache["box_color"] = mode_name, mode_bgr
                    else:
                        # Provisional value shown until we've collected enough samples.
                        cache["color_name"], cache["box_color"] = name, bgr

                # --- OCR: skip if already locked, crop too small, or too soon to retry ---
                area = (x2 - x1) * (y2 - y1)
                if not cache["plate_locked"] and area >= MIN_PLATE_CROP_AREA:
                    if cache["frames_since_ocr"] >= OCR_RETRY_INTERVAL:
                        text, conf = extract_license_plate(crop, ocr_reader)
                        cache["frames_since_ocr"] = 0
                        if text and conf > cache["plate_conf"]:
                            cache["plate_text"] = text
                            cache["plate_conf"] = conf
                        if conf >= PLATE_LOCK_CONFIDENCE:
                            cache["plate_locked"] = True
                    else:
                        cache["frames_since_ocr"] += 1

                class_name = VEHICLE_CLASSES.get(cls_id, "vehicle")
                draw_annotation(frame, (x1, y1, x2, y2), track_id, cache, class_name,
                                 font_scale=draw_font_scale,
                                 font_thickness=draw_font_thickness,
                                 box_thickness=draw_box_thickness)

            # --- Cleanup: drop cached data for tracks not seen in a while ---
            stale_ids = [tid for tid, c in track_cache.items()
                         if c is not None and frame_idx - c["last_seen"] > TRACK_TTL_FRAMES]
            for tid in stale_ids:
                del track_cache[tid]

            # --- FPS overlay ---
            now = time.time()
            instant_fps = 1.0 / max(now - prev_time, 1e-6)
            prev_time = now
            fps_smoothed = fps_smoothed * 0.9 + instant_fps * 0.1 if fps_smoothed else instant_fps
            status = f"FPS: {fps_smoothed:.1f} | Tracks: {len(seen_ids_this_frame)}"
            if consecutive_empty_frames >= EMPTY_FRAMES_BEFORE_SKIP:
                status += " | mode: sparse-skip"
            status_y = int(30 / display_scale) if display_scale > 0 else 30
            cv2.putText(frame, status, (int(10 / display_scale), status_y),
                        cv2.FONT_HERSHEY_SIMPLEX, draw_font_scale, (0, 255, 0),
                        draw_font_thickness, cv2.LINE_AA)

            if not args.no_display:
                if display_scale < 1.0:
                    display_frame = cv2.resize(
                        frame,
                        (int(round(w_frame * display_scale)), int(round(h_frame * display_scale))),
                        interpolation=cv2.INTER_AREA,
                    )
                else:
                    display_frame = frame

                if not window_ready:
                    cv2.namedWindow("Traffic Analysis", cv2.WINDOW_NORMAL)
                    cv2.resizeWindow("Traffic Analysis",
                                      display_frame.shape[1], display_frame.shape[0])
                    window_ready = True

                cv2.imshow("Traffic Analysis", display_frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    print("[run] 'q' pressed. Exiting.")
                    break
    except KeyboardInterrupt:
        print("[run] Interrupted by user.")
    finally:
        stream.release()
        cv2.destroyAllWindows()
        print("[run] Shutdown complete.")


if __name__ == "__main__":
    main()
