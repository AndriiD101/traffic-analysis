"""
Helper functions for the real-time traffic analysis pipeline.

Contains:
  - get_dominant_color: fast, edge-friendly car color estimation.
  - extract_license_plate: EasyOCR-based plate text extraction.
  - init_ocr_reader: lazy EasyOCR reader construction.
"""

import re

import cv2
import numpy as np

# ---------------------------------------------------------------------------
# Color detection
# ---------------------------------------------------------------------------

# Fixed, visually distinct BGR values used to draw bounding boxes. We map any
# detected pixel to the nearest *named* color and draw with this fixed value,
# so boxes stay visually consistent even when the raw sampled pixel is noisy
# (reflections, shadows, JPEG/RTSP compression artifacts, etc.).
_COLOR_DRAW_BGR = {
    "white":  (245, 245, 245),
    "black":  (20, 20, 20),
    "gray":   (128, 128, 128),
    "silver": (192, 192, 192),
    "red":    (0, 0, 220),
    "blue":   (200, 60, 0),
    "green":  (0, 140, 0),
    "yellow": (0, 220, 220),
    "orange": (0, 140, 255),
    "brown":  (30, 60, 110),
}


def _classify_hsv(h, s, v):
    """
    Classify a single HSV pixel (OpenCV ranges: H in [0,179], S/V in [0,255])
    into one of a small set of common vehicle colors using simple threshold
    rules. This is intentionally rule-based rather than a trained classifier
    to keep it near-zero cost on edge hardware.
    """
    if v < 45:
        return "black"
    if s < 35 and v > 190:
        return "white"
    if s < 45:
        return "silver" if v > 130 else "gray"

    if h < 8 or h >= 170:
        return "red"
    if 8 <= h < 20:
        return "orange" if v > 120 else "brown"
    if 20 <= h < 33:
        return "yellow"
    if 33 <= h < 85:
        return "green"
    if 85 <= h < 130:
        return "blue"
    if 130 <= h < 170:
        return "red" if s > 150 else "silver"
    return "gray"


def get_dominant_color(image_crop, k=3, sample_size=48):
    """
    Estimate the dominant exterior color of a vehicle crop.

    Strategy (deliberately lightweight for real-time/edge inference):
      1. Take the central region of the bounding box (skips background,
         windshield glare/reflections, and shadows near the box edges).
      2. Downsample aggressively before clustering (K-Means on ~48x48 px is
         essentially free on CPU, vs. running on the full-res crop).
      3. Run K-Means (k=3), pick the largest cluster's centroid as the
         representative color.
      4. Classify that centroid in HSV space into a named color and return a
         fixed BGR value for drawing.

    Returns:
        (color_name: str, box_color_bgr: tuple[int, int, int])
    """
    if image_crop is None or image_crop.size == 0:
        return "unknown", (0, 255, 0)

    h, w = image_crop.shape[:2]
    if h < 4 or w < 4:
        return "unknown", (0, 255, 0)

    # Center crop: keep the middle ~60% width / 50% height (vehicle body).
    cx0, cx1 = int(w * 0.20), int(w * 0.80)
    cy0, cy1 = int(h * 0.35), int(h * 0.85)
    center = image_crop[cy0:cy1, cx0:cx1]
    if center.size == 0:
        center = image_crop

    small = cv2.resize(center, (sample_size, sample_size), interpolation=cv2.INTER_AREA)
    pixels = small.reshape(-1, 3).astype(np.float32)

    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    k_eff = max(1, min(k, len(pixels)))

    try:
        if k_eff == 1:
            dominant_bgr = pixels.mean(axis=0)
        else:
            _compactness, labels, centers = cv2.kmeans(
                pixels, k_eff, None, criteria, 3, cv2.KMEANS_PP_CENTERS
            )
            counts = np.bincount(labels.flatten())
            dominant_bgr = centers[np.argmax(counts)]
    except cv2.error:
        dominant_bgr = pixels.mean(axis=0)

    b, g, r = [int(np.clip(c, 0, 255)) for c in dominant_bgr]
    hsv_pixel = cv2.cvtColor(np.uint8([[[b, g, r]]]), cv2.COLOR_BGR2HSV)[0][0]
    color_name = _classify_hsv(int(hsv_pixel[0]), int(hsv_pixel[1]), int(hsv_pixel[2]))
    box_color = _COLOR_DRAW_BGR.get(color_name, (b, g, r))
    return color_name, box_color


# ---------------------------------------------------------------------------
# License plate OCR
# ---------------------------------------------------------------------------

_PLATE_CLEAN_RE = re.compile(r"[^A-Z0-9]")


def init_ocr_reader(languages=("en",), gpu=False):
    """
    Lazily construct the EasyOCR reader. EasyOCR's import + model download
    is heavy, so this should be called exactly once at startup, not per frame.
    """
    import easyocr  # local import: avoids paying the import cost if unused
    return easyocr.Reader(list(languages), gpu=gpu, verbose=False)


def extract_license_plate(image_crop, reader, min_conf=0.35, min_text_len=4, max_text_len=10):
    """
    Attempt to read a license plate from a vehicle crop using EasyOCR.

    Rather than running a dedicated plate-detector model, this feeds EasyOCR
    the lower portion of the vehicle's bounding box (where plates are usually
    mounted) and filters/cleans the resulting text. This keeps the pipeline
    to two models total (YOLOv8n + EasyOCR), which matters for edge/real-time
    budgets.

    Returns:
        (text: str | None, confidence: float)
    """
    if image_crop is None or image_crop.size == 0:
        return None, 0.0

    h, w = image_crop.shape[:2]
    if h < 10 or w < 10:
        return None, 0.0

    # Plates are usually in the lower half of the vehicle's bbox (front or
    # rear plate), so restrict OCR to that region to cut both compute and
    # false positives from windows/text elsewhere on the car.
    roi = image_crop[int(h * 0.45):h, 0:w]
    if roi.size == 0:
        roi = image_crop

    # Upscale small crops - OCR accuracy drops sharply on tiny text.
    if roi.shape[0] < 60:
        scale = 60.0 / max(roi.shape[0], 1)
        roi = cv2.resize(roi, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 7, 50, 50)
    gray = cv2.equalizeHist(gray)

    try:
        results = reader.readtext(gray, detail=1, paragraph=False)
    except Exception:
        return None, 0.0

    best_text, best_conf = None, 0.0
    for _bbox, text, conf in results:
        cleaned = _PLATE_CLEAN_RE.sub("", text.upper())
        if not (min_text_len <= len(cleaned) <= max_text_len):
            continue
        if conf > best_conf:
            best_text, best_conf = cleaned, conf

    if best_text and best_conf >= min_conf:
        return best_text, float(best_conf)
    return None, 0.0
